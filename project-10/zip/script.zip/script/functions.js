import { songs } from "./song.js";

let autoSuffleBtn = false;
let loopSong = false;

export function playAndPauseSong(song) {

    const playBtns = document.querySelectorAll(".playBtn");

    if (song.paused) {
        song.play();
        playBtns.forEach(btn => {
            btn.innerHTML = `<i class="fa-solid fa-pause"></i>`;
        });

    } else {
        song.pause();
        playBtns.forEach(btn => {
            btn.innerHTML = `<i class="fa-solid fa-play"></i>`;
        });
    }
}

export function formatTime(time) {
    let minutes = Math.floor(time / 60);
    let seconds = Math.floor(time % 60);

    if (seconds < 10) {
        seconds = "0" + seconds;
    }

    return `${minutes}:${seconds}`;
}

export function songPlay(songid) {
    let html = "";
    songs.forEach((song) => {
        if (song.songId === songid) {
            html = `
            <img class="album-cover" src="${song.songImage}">

            <div class="player-content">

                <!-- Desktop -->
                <div class="desktop-player">

                    <div class="song-details">
                        <h2 class="song-name">${song.songName}</h2>
                        <p class="artist-name">${song.ArtistName}</p>
                    </div>

                    <audio class="audio">
                        <source src="${song.songSrc}">
                    </audio>

                    <input class="song-time" type="range">

                    <div class="time-info">
                        <span class="current-time">0:00</span>
                        <span class="duration">0:00</span>
                    </div>

                    <div class="buttons">

                        <button class="suffleBtn"><i class="fa-solid fa-shuffle"></i></button>

                        <div class="main-buttons">
                            <button class="previousBtn">
                                <i class="fa-solid fa-backward-step"></i>
                            </button>

                            <button class="playBtn">
                                <i class="fa-solid fa-play"></i>
                            </button>

                            <button class="nextBtn">
                                <i class="fa-solid fa-forward-step"></i>
                            </button>
                        </div>

                        <button class="loopSong"><i class="fa-solid fa-repeat"></i></button>

                    </div>

                </div>

                <!-- Mobile -->
                <div class="mobile-player">

                    <span class="current-time">0:00</span>

                    <input class="song-time" type="range">

                    <span class="duration">0:00</span>

                    <button class="previousBtn"><i class="fa-solid fa-backward-step"></i></button>
                    <button class="playBtn"><i class="fa-solid fa-play"></i></button>
                    <button class="nextBtn"><i class="fa-solid fa-forward-step"></i></button>

                </div>

            </div>
            `
        }
    })
    return html;
}

export function randerSong(activeSong, songid, onSongEnd) {

    const currentSong = document.querySelector(".audio");

    const playBtns = document.querySelectorAll(".playBtn");
    const ranges = document.querySelectorAll(".song-time");
    const currentTimes = document.querySelectorAll(".current-time");
    const durations = document.querySelectorAll(".duration");
    const nextSong = document.querySelectorAll('.nextBtn');
    const previousBtn = document.querySelectorAll(".previousBtn")
    const fullPlayer = document.querySelector(".full-player");

    const fullPlay = document.querySelector(".full-play");
    const fullNext = document.querySelector(".full-next");
    const fullPrevious = document.querySelector(".full-previous");

    const fullCurrentTime = document.querySelector(".full-current-time");
    const fullDuration = document.querySelector(".full-duration");

    const fullRange = document.querySelector(".full-song-time");

    let isDragging = false;

    fullRange.onpointerdown = () => {
        isDragging = true;
    };

    fullRange.onpointerup = () => {
        isDragging = false;
    };

    fullRange.onpointercancel = () => {
        isDragging = false;
    };

    fullRange.oninput = () => {
        if (!currentSong.duration) return;

        currentSong.currentTime =
            (Number(fullRange.value) / 100) * currentSong.duration;
    };

    fullPlay.onclick = () => {
        playAndPauseSong(currentSong);
    };

    fullNext.onclick = () => {
        onSongEnd(songid);
    };

    fullPrevious.onclick = () => {
        onSongEnd(songid - 2);
    };


    currentSong.addEventListener("play", () => {

        playBtns.forEach(btn => {
            btn.innerHTML = `<i class="fa-solid fa-pause"></i>`;
        });

        if (fullPlay) {
            fullPlay.innerHTML =
                `<i class="fa-solid fa-pause"></i>`;
        }

    });


    currentSong.addEventListener("pause", () => {

        playBtns.forEach(btn => {
            btn.innerHTML = `<i class="fa-solid fa-play"></i>`;
        });

        if (fullPlay) {
            fullPlay.innerHTML =
                `<i class="fa-solid fa-play"></i>`;
        }

    });


    const suffleBtn = document.querySelector(".suffleBtn");
    if (autoSuffleBtn) {
        suffleBtn.classList.add("suffleBtnActive");
    } else {
        suffleBtn.classList.remove("suffleBtnActive");
    }
    const loopBtn = document.querySelector(".loopSong")
    if (loopSong) {
        loopBtn.classList.add("loopSongActive");
    } else {
        loopBtn.classList.remove("loopSongActive");
    }

    suffleBtn.addEventListener("click", () => {
        autoSuffleBtn = !autoSuffleBtn;
        suffleBtn.classList.toggle(
            "suffleBtnActive",
            autoSuffleBtn
        );

        if (autoSuffleBtn) {
            loopSong = false;

            loopBtn.classList.remove("loopSongActive");
        }
    });

    loopBtn.addEventListener("click", () => {

        loopSong = !loopSong;

        loopBtn.classList.toggle(
            "loopSongActive",
            loopSong
        );

        if (loopSong) {
            autoSuffleBtn = false;

            suffleBtn.classList.remove("suffleBtnActive");
        }
    });

    nextSong.forEach((songBtn) => {
        songBtn.addEventListener('click', () => {
            onSongEnd(songid);
        });
    });

    previousBtn.forEach((songBtn) => {
        songBtn.addEventListener('click', () => {
            onSongEnd(songid - 2)
        });
    });

    currentSong.play();
    playBtns.forEach(btn => {
        btn.innerHTML = `<i class="fa-solid fa-pause"></i>`;
    });

    currentSong.addEventListener("loadedmetadata", () => {

        const duration = formatTime(currentSong.duration);

        durations.forEach(time => {
            time.innerText = duration;
        });

        if (fullDuration) {
            fullDuration.innerText = duration;
        }

    });

    currentSong.addEventListener("timeupdate", () => {

        if (!currentSong.duration) return;

        const value =
            (currentSong.currentTime / currentSong.duration) * 100;

        // Normal player
        ranges.forEach(range => {
            range.value = value;
        });

        currentTimes.forEach(time => {
            time.innerText = formatTime(currentSong.currentTime);
        });

        durations.forEach(time => {
            time.innerText = formatTime(currentSong.duration);
        });


        // Full player
        if (fullRange && !isDragging) {
            fullRange.value = value;
        }

        if (fullCurrentTime) {
            fullCurrentTime.innerText =
                formatTime(currentSong.currentTime);
        }

        if (fullDuration) {
            fullDuration.innerText =
                formatTime(currentSong.duration);
        }

    });

    ranges.forEach(range => {
        range.addEventListener("input", () => {
            currentSong.currentTime =
                (range.value / 100) * currentSong.duration;
        });
    });

    playBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            playAndPauseSong(currentSong);
        });
    });

    currentSong.addEventListener("ended", () => {

        if (loopSong) {
            currentSong.currentTime = 0;
            currentSong.play();
            return;
        }

        if (autoSuffleBtn) {
            onSongEnd(AutoSuffle() - 1)
        } else {
            onSongEnd(songid);
        }
    });

    function AutoSuffle() {
        let randomID = Math.floor(Math.random() * songs.length) + 1;
        if (randomID === songid) {
            randomID = Math.floor(Math.random() * songs.length) + 1;
        }
        return randomID
    }
}

export function toggleShuffle() {
    autoSuffleBtn = !autoSuffleBtn;

    if (autoSuffleBtn) {
        loopSong = false;
    }

    return {
        shuffle: autoSuffleBtn,
        loop: loopSong
    };
}

export function toggleLoop() {
    loopSong = !loopSong;

    if (loopSong) {
        autoSuffleBtn = false;
    }

    return {
        shuffle: autoSuffleBtn,
        loop: loopSong
    };
}


